def comptage(tableau,ligne,colonne):
    res = 0
    modif = True
    while(modif == True):
        modif = False
        for l in range(ligne): 
            for c in range(colonne): 
                valeur = tableau[l][c]
                if l>0 : 
                    tmp = tableau[l-1][c]
                    diff = abs(tmp-valeur) -1
                    if tmp <= valeur -2 : 
                       tableau[l-1][c] += diff
                       res += diff
                       modif = True 
                    if tmp >= valeur +2 : 
                        tableau[l][c] += diff
                        res += diff
                        modif = True 
                if c>0 : 
                    tmp = tableau[l][c-1]
                    diff = abs(tmp-valeur) -1
                    if tmp <= valeur -2 : 
                       tableau[l][c-1] += diff 
                       res += diff
                       modif = True 
                    if tmp >= valeur +2 : 
                        tableau[l][c] += diff
                        res += diff
                        modif = True 
                if l<ligne-1 : 
                    tmp = tableau[l+1][c]
                    diff = abs(tmp-valeur) -1
                    if tmp <= valeur -2 : 
                       tableau[l+1][c] += diff 
                       res += diff
                       modif = True 
                    if tmp >= valeur +2 : 
                        tableau[l][c] += diff
                        res += diff
                        modif = True 
                if c<colonne-1 : 
                    tmp = tableau[l][c+1]
                    diff = abs(tmp-valeur) -1
                    if tmp <= valeur -2 : 
                       tableau[l][c+1] += diff 
                       res += diff
                       modif = True 
                    if tmp >= valeur +2 : 
                        tableau[l][c] += diff
                        res += diff
                        modif = True 
    return res


def algo() : 

    output = []

    test = int(input())

    for i in range(1,test+1) : 
        
        ligne = input().split()
        R = int(ligne[0])
        C = int(ligne[1])
        tableau = []
        
        for x in range(R):
            ligne = []
            mot = input().split()
            for y in range(C):
                ligne.append(int(mot[y]))
            tableau.append(ligne)

        score = comptage(tableau, R, C)
        s = "Case #"+str(i)+": "+str(score)
        output.append(s)

    for l in output : 
        print(l)

algo()       
