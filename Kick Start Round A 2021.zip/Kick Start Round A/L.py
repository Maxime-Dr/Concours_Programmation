def comptage(tableau,ligne,colonne):
    res = 0
    for l in range(ligne):
        for c in range(colonne): 
            if tableau[l][c] == 1 : 
                nord = 0
                est = 0
                sud = 0
                ouest = 0
                for es in range(c,colonne):
                    if tableau[l][es] == 1 : 
                        est += 1
                    else : 
                        break
                for su in range(l,ligne): 
                    if tableau[su][c] == 1 :
                        sud += 1
                    else : 
                        break
                for ou in range(c,-1,-1):
                    if tableau[l][ou] == 1 : 
                        ouest += 1
                    else : 
                        break
                for no in range(l,-1,-1): 
                    if tableau[no][c] == 1 :
                        nord += 1
                    else : 
                        break

                if est >= 2 and sud >= 2 : 
                    if est > sud: 
                        print((l,c))
                        res += est//sud
                    elif est == sud and est > 3 : 
                        res += est // 2
                    else : 
                        res += sud // est
                if sud >= 2 and ouest >= 2 : 
                    if ouest >= 4 or sud >= 4 : 
                        print((l,c))
                        res += 1
                if ouest >= 2 and nord >= 2 : 
                    if (ouest >= 4) or (nord >= 4) : 
                        print((l,c))
                        res += 1
                if nord >= 2 and est >= 2 : 
                    if est >= 4 or nord >= 4 : 
                        print((l,c))
                        res += 1

    return res


def algo() : 

    output = []

    test = int(input())

    for i in range(1,test+1) : 
        
        ligne = input().split()
        R = int(ligne[0])
        C = int(ligne[1])
        tableau = []
        
        for x in range(R):
            ligne = []
            mot = input().split()
            for y in range(C):
                ligne.append(int(mot[y]))
            tableau.append(ligne)

        score = comptage(tableau, R, C)
        s = "Case #"+str(i)+": "+str(score)
        output.append(s)

    for l in output : 
        print(l)

algo()       
