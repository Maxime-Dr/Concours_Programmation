def score(s,n):
    res = 0;
    compteur = n-1
    if n%2 == 0 : 
        for i in range((n//2)): 
            if s[i] != s[compteur-i] : 
                res += 1
    else : 
        for i in range(((n-1)//2)):
            if s[i] != s[compteur-i] : 
                res += 1
    return res

def nb_modification(s,n,k,score): 
    diff = 0
    if k > score : 
        diff = k - score
    else : 
        diff = score - k
    return diff


def algo() : 

    output = []

    test = int(input())

    for i in range(1,test+1) : 
        ligne = input().split()
        N = int(ligne[0])
        K = int(ligne[1])
        mot = input()

        scor = score(mot, N)

        if scor == K : 
            s = "Case #"+str(i)+": 0"
            output.append(s)
        else : 
            modif = nb_modification(mot,N,K,scor)
            s = "Case #"+str(i)+": "+str(modif)
            output.append(s)
    
    for l in output : 
        print(l)

algo()
