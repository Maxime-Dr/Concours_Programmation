import random

def data(dico,n): 
    for i in range(1,n+1): 
        for j in range(i+1,n+1):
            for k in range(j+1,n+1):
                if i!=j and j!= k and i != k : 
                    print(str(i) + " " + str(j) +" "+ str(k))
                    med = int(input())
                    if med == i : 
                        dico[med-1].append((j,k))
                    elif med == j:
                        dico[med-1].append((i,k))
                    else : 
                        dico[med-1].append((i,j))
    return dico

def comptage(d,n): 
    l = []
    for i in range(len(d)):
        l.append((i,len(d[i])))
    l.sort(key=lambda tup: tup[1])
    return l
        
def solution(d,dico,n):
    sol = [0 for x in range(n)]
    pileD = []
    pileG = []
    LasrEleG = None
    compteur = 0
    if n%2==0 : 
        i = 0
        while i < (n//2) :
            A = dico[compteur][0]+1
            compteur += 1
            B = dico[compteur][0]+1
            compteur +=1
            if len(pileG)==0 : 
                pileG.append(A)
                LasrEleG = A
                pileD.append(B)
            else : 
                tupC = (LasrEleG,B)
                tupD = (B,LasrEleG)
                if tupC in d[A-1] or tupD in d[A-1] : 
                    pileG.append(A)
                    pileD.append(B)
                    LasrEleG = A
                else : 
                    pileG.append(B)
                    pileD.append(A)
                    LasrEleG = B
            i += 1
    else : 
        i = 0
        while i < (n//2) :
            A = dico[compteur][0]+1
            compteur += 1
            B = dico[compteur][0]+1
            compteur +=1
            if len(pileG)==0 : 
                pileG.append(A)
                LasrEleG = A
                pileD.append(B)
            else : 
                tupC = (LasrEleG,B)
                tupD = (B,LasrEleG)
                if tupC in d[A-1] or tupD in d[A-1] : 
                    pileG.append(A)
                    pileD.append(B)
                    LasrEleG = A
                else : 
                    pileG.append(B)
                    pileD.append(A)
                    LasrEleG = B
            i+= 1
        pileG.append(dico[compteur][0]+1)
    count = 0
    pileD.reverse()
    for e in pileG: 
        sol[count] = e
        count += 1
    for e in pileD : 
        sol[count] = e
        count += 1
    return sol

def algo() : 

    ligne = input().split()
    test = int(ligne[0])
    N = int(ligne[1])
    Q = int(ligne[2])
    
    for i in range(1,test+1) : 
        d = [[] for x in range(N)]
        sol = []
        d = data(d,N)
        dico = comptage(d,N)
        sol = solution(d,dico,N)
        s = ""
        for ind in range(N):
            if ind == N-1:
                s += str(sol[ind])
            else: 
                s += str(sol[ind])+" "
        print(s)
        res = int(input())

algo()