import random
import math


def Convert(string):
    list1=[]
    list1[:0]=string
    return list1


def algo() : 
    output = []

    test = int(input())
    P = int(input())

    for i in range(1,test+1) : 
        resultat = []
        for x in range(100): 
            ligne = Convert(input())
            good = 0
            for c in ligne:
                if int(c)==1 : 
                    good += 1
            resultat.append((x,good))
        resultat.sort(key=lambda tup: tup[1],reverse=True)
       
        s = "Case #"+str(i)+": "+str(resultat[0][0]+1)
        output.append(s)
    
    for l in output : 
        print(l)
        

algo()