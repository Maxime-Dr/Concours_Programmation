def reverse(tab,i,j):
    tmp = []
    for e in range(i,j): 
        tmp.append(tab[e])
    tmp.reverse()
    for e in range(len(tmp)):
        tab[e+i]=tmp[e]

def reverseSort(n,c):
    if c == n-1 : 
        tab = [x for x in range(1,n+1)]
        return tab

    tab = [x for x in range(n)]
    sol = []
    res = 0

    for i in range(1,n+1): 
        #print("pour ",i)
        for p in range(0,n-i+1):
            maxi = p + 1 + possMax(n-i) + res 
            mini = p+1 + (n-i)-1 + res
            #print(maxi)
            #print(mini)
            if mini <= c and c <= maxi : 
                #print(maxi)
                #print(mini)
                indice = p + i - 1
                res += p + 1
                sol.append((i,tab[indice]))
                #print(res)
                #print(sol)
                #print(tab)
                reverse(tab,i-1,indice+1)
                #print(tab)
                break
    #print("fini")
    resultat = [0 for x in range(n)]
    for s in sol: 
        resultat[s[1]] = s[0]
    return resultat


def possMax(i):
    res = 0
    for j in range(0,i-1):
        res += i-j
    return res

def algo() : 

    output = []

    test = int(input())

    for i in range(1,test+1) : 
        ligne = input().split()
        N = int(ligne[0])
        C = int(ligne[1])
        
        if C > possMax(N) or C < N-1: 
            s = "Case #"+str(i)+": IMPOSSIBLE"
            output.append(s)
        else : 
            tab = reverseSort(N,C)
            rep = ""
            for ind in range(N):
                if ind == N-1:
                    rep += str(tab[ind])
                else: 
                    rep += str(tab[ind])+" "
            s = "Case #"+str(i)+": "+rep
            output.append(s)
    
    for l in output : 
        print(l)

algo()
#print(reverseSort(4,6))
#print(possMax(3))
