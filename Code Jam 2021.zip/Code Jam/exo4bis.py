import random

def miseAjour(tab,med,a,b): 
    tmp = []
    findA = False
    findB = False
    findM = False
    for ele in tab: 
        if ele == a :
            if findA==False : 
                if findB==True and findM==False:
                    tmp.append(med)
                    tmp.append(a)
                    findM=True
                else:
                    tmp.append(a)
                findA=True
        elif ele == b:
            if findB==False:
                if findA==True and findM==False:
                    tmp.append(med)
                    tmp.append(b)
                    findM=True
                else:
                    tmp.append(b)
                findB=True
        elif ele == med :
            if findM == False:
                if findA == False and findB==False:
                    tmp.append(a)
                    tmp.append(med)
                    findA=True
                else : 
                    tmp.append(med)
                findM=True
        else : 
            tmp.append(ele)
    if findA and findB and findM :
        return tmp
    elif findA==False and findB==False and findM==False:
        tmp.append(a)
        tmp.append(med)
        tmp.append(b)
    elif findM==False and findB==False : 
        tmp.append(med)
        tmp.append(b)
    elif findA==False and findM==False : 
        tmp.append(med)
        tmp.append(a)
    elif findA==False:
        tmp.append(a)
    elif findB ==False: 
        tmp.append(b)
    else : 
        return tmp
    return tmp

def bienForme(tab, med,a,b):
    indexA = 0
    indexB = 0
    indexM = 0
    for i in range(len(tab)):
        if tab[i]==a:
            indexA = i
        if tab[i]==b:
            indexB = i
        if tab[i]==med:
            indexM = i
    if indexA < indexM and indexM < indexB : 
        return True
    elif indexB < indexM and indexM < indexA : 
        return True
    else : 
        return False

def choose(tab,dico,med,a,b,n):
    valeur_a = med
    valeur_b = a
    while 1 : 
        if len(tab) == n: 
            for i in range(n-2): 
                E = tab[i]
                F = tab[i+1]
                G = tab[i+2]
                if ((E,G) not in dico[F-1] and (G,E) not in dico[F-1]):
                    return F,E,G
            while(1): 
                valeur_b = random.randint(1,n)
                valeur_c = random.randint(1,n)
                if (valeur_b,valeur_c) not in dico[med] and (valeur_c,valeur_b) not in dico[med]:
                    return valeur_a,valeur_b,valeur_c
        else : 
            valeur_c = random.randint(1,n)
            if valeur_c not in tab :
                break;
    return valeur_a,valeur_b,valeur_c


def complet(tab, dico,n): 
    if len(tab) < n: 
        return False
    for i in range(n-2): 
        E = tab[i]
        F = tab[i+1]
        G = tab[i+2]
        if ((E,G) not in dico[F-1] and (G,E) not in dico[F-1]):
            return False
    return True

def fini(sol,dico): 
    for i in range(len(dico)):
        for t in dico[i]: 
            a = t[0]
            b = t[1]
            if bienForme(sol,i+1, a,b)==False : 
                return False
    return True

def algo() : 

    ligne = input().split()
    test = int(ligne[0])
    N = int(ligne[1])
    Q = int(ligne[2])
    
    for i in range(1,test+1) : 
        compteur = 0
        dico = [[] for x in range(N)]
        sol = []
        a,b,c = 1,2,3
        med,va,vb = None,None,None
        while compteur < Q : 
            if compteur >= 1:
                a,b,c = choose(sol,dico,med,va,vb,N)
            print(str(a) + " " + str(b) +" "+ str(c))
            med = int(input())
            va = None
            vb = None
            if med == a : 
                dico[med-1].append((b,c))
                va = b
                vb = c
            elif med == b:
                dico[med-1].append((a,c))
                va = a
                vb = c
            else : 
                dico[med-1].append((a,b))
                va = a
                vb = b

            sol = miseAjour(sol,med,va,vb)
            if complet(sol,dico,N): 
                if fini(sol,dico) :
                    s = ""
                    for ind in range(N):
                        if ind == N-1:
                            s += str(sol[ind])
                        else: 
                            s += str(sol[ind])+" "
                    print(s)
                    res = int(input())
                    if res == 1 : 
                        break
            compteur += 1

algo()