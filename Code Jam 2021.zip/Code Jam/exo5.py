import random
import math

def sigmoid(x):
  return 1 / (1 + math.exp(-x))

def Convert(string):
    list1=[]
    list1[:0]=string
    return list1

def cheat(eleves, question): 
    tricheur = []
    for i in range(100): 
        if eleves[i][2] < 7400 : 
            continue
        soupsons = 0
        intel = eleves[i][0]
        rep = eleves[i][1]
        for j in range(10000): 
            reussite = sigmoid(intel-question[j])
            if reussite <= 0.02 and rep[j]==1: 
                soupsons += 1
        if soupsons > 0: 
            tricheur.append((i,soupsons))
    tricheur.sort(key=lambda tup: tup[1],reverse=True)
    return tricheur


def algo() : 
    output = []

    test = int(input())
    P = int(input())

    for i in range(1,test+1) : 
        question = [0.0 for x in range(10000)]
        for x in range(10000): 
            question[x] = round(random.uniform(-3.00, 3.00), 11)
        eleves = {}
        for x in range(100): 
            ligne = Convert(input())
            good = 0
            reponse = []
            for c in ligne:
                reponse.append(int(c))
                if int(c)==1 : 
                    good += 1
            skill = round(random.uniform(-3.00, 3.00), 8)
            eleves[x] = (skill,reponse,good)
        meilleurs = []
        for k,tup in eleves.items(): 
            meilleurs.append((k,tup[2]))
        meilleurs.sort(key=lambda tup: tup[1],reverse=True)
        tricheurs = cheat(eleves,question)
        #print(meilleurs)
        #print(tricheurs)
        best_meil = meilleurs[0:2]
        best_tri = tricheurs[0:10]
        #print(best_meil)
        #print(best_tri)
        reponse = None
        TRI = []
        for b in best_tri:
            TRI.append(b[0])
        for tri in best_meil:
            if tri[0] in TRI:
                reponse = tri[0]
                break
        if reponse == None : 
            reponse = meilleurs[0][0]
        
        s = "Case #"+str(i)+": "+str(reponse+1)
        output.append(s)
    
    for l in output : 
        print(l)
        

algo()