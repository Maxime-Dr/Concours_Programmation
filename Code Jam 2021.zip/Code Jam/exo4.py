import random

def quicksort(tab):
    if len(tab)<= 1: 
        return tab
    else : 
        G = set()
        D = set()
        x = random.randint(0,len(tab)-1)
        for i in range(len(tab)): 
            for j in range(i+1,len(tab)):
                if i!= x and j != x: 
                    print(str(tab[i]) + " " + str(tab[j]) +" "+ str(tab[x]))
                    med = int(input())
                    if med == tab[i] or med == tab[j]: 
                        D.add(tab[i])
                        D.add(tab[j])
        for e in tab : 
            if e!=tab[x] and e not in D : 
                G.add(e)
        print(G)
        print(D)
        return quicksort(list(G))+[x]+quicksort(list(D))

                        
def algo() : 

    ligne = input().split()
    test = int(ligne[0])
    N = int(ligne[1])
    Q = int(ligne[2])
    
    for i in range(1,test+1) : 
        tab = [x for x in range(1,N+1)]
        sol = quicksort(tab)
        s = ""
        for ind in range(N):
            if ind == N-1:
                s += str(sol[ind])
            else: 
                s += str(sol[ind])+" "
        print(s)
        res = int(input())

algo()