def reverseSort(tab): 
    res = 0
    for i in range(1,len(tab)) : 

        j = i-1
        mini = tab[i-1]
        for k in range(i,len(tab)): 
            if tab[k]<mini : 
                j = k
                mini = tab[k]
        tmp = []
        for e in range(i-1,j+1): 
            tmp.append(tab[e])
        tmp.reverse()
        res += len(tmp)
        for e in range(len(tmp)):
            tab[e+(i-1)]=tmp[e]
    return res

def algo() : 

    output = []

    test = int(input())

    for i in range(1,test+1) : 
        L = int(input())
        ligne = input().split()
        tab = []
        for e in ligne: 
            tab.append(int(e))

        score = reverseSort(tab)
        s = "Case #"+str(i)+": "+str(score)
        output.append(s)
    
    for l in output : 
        print(l)

#algo()

print(reverseSort([4,2,1,3]))
print(reverseSort([2,3,1,4]))

