def Convert(string):
    list1=[]
    list1[:0]=string
    return list1

def resolution(x,y,mur): 
    res = 0
    for i in range(len(mur)-1):
        if mur[i]=='C': 
            if mur[i+1] == 'J': 
                res += x
            if mur[i+1] == '?':
                if i+1 == len(mur)-1 : 
                    return res
                else : 
                    mur[i+1] = 'C'
        elif mur[i]=='J':
            if mur[i+1] == 'C': 
                res += y
            if mur[i+1] == '?':
                if i+1 == len(mur)-1 : 
                    return res
                else : 
                    mur[i+1] = 'J'
        else: 
            res+=0
    return res


def algo() : 

    output = []

    test = int(input())

    for i in range(1,test+1) : 
        ligne = input().split()
        X = int(ligne[0])
        Y = int(ligne[1])
        mur = Convert(ligne[2])

        score = resolution(X,Y,mur)
        s = "Case #"+str(i)+": "+str(score)
        output.append(s)
    
    for l in output : 
        print(l)

algo()