import sys

def parseur():
	with open(sys.argv[1]) as file:
		ligne = file.readline().split(' ')
		D = int(ligne[0])
		I = int(ligne[1])
		S = int(ligne[2])
		V = int(ligne[3])
		F = int(ligne[4])

		mapGoogle = {}
		timeStreet = {}
		cars = {}
		
		#for l in range(I):
			#mapGoogle[l] = (set(), set()) # entree sortie
		
		for i in range(S): 
			ligne = file.readline().split(' ')
			B = int(ligne[0])
			E = int(ligne[1])
			streetName = ligne[2]
			L = int(ligne[3])
			timeStreet[streetName] = L
			#mapGoogle[B][0].add(streetName)
			#mapGoogle[E][1].add(streetName)
			mapGoogle[streetName] = (B, E)             

		for j in range(V):
			ligne = file.readline().split(' ')
			ligne[len(ligne)-1] = ligne[len(ligne)-1].rstrip()
			P = int(ligne[0])
			rueVue = ligne[1:]
			trajet = 0
			for rue in rueVue:
				trajet += timeStreet[rue]
			
			cars[j] = (P, rueVue, 0, trajet)

	return mapGoogle, timeStreet, cars, D
            

			
def interIsPresent(s, i):
	for t in s:
		if i == t[0]:
			return True
	return False


def algo(mapGoogle, timeStreet, cars, D):
	cars = dict(sorted(cars.items(), key=lambda t: t[1][3]))
	temps = {}
	for i in range(0, D):
		temps[i] = set()
	for (k, v) in cars.items(): 
		second = 0
		wait = False
		for j in range(0, v[0]):
			if second == D : 
				break
			if j == 0 :
				inter = mapGoogle[v[1][j]][1]
				if interIsPresent(temps[second], inter) : 
					j = j-1
				else : 
					temps[second].add((inter, v[1][j]))
				second += 1
			else : 
				if wait == False :
					second += timeStreet[v[1][j]]
				else :
					second += 1
				if second >= D : 
						break
				inter = mapGoogle[v[1][j]][1]
				if interIsPresent(temps[second], inter) :  
					j = j-1
					wait = True
				else : 
					temps[second].add((inter, v[1][j]))
					wait = False
	return temps

def analyse(temps, D) : 
	intersection = {}
	for (k, v) in temps.items(): 
		l = list(v)
		for ele in l:
			if ele[0] in intersection and (ele[1], 1) not in intersection:
				intersection[ele[0]].add((ele[1], 1))
			else: 
				intersection[ele[0]] = set()
				intersection[ele[0]].add((ele[1], 1))
	A = len(intersection)
	return A, intersection


		

def output(A, intersection): #mettre le retour de analyse
	with open("resultat.txt", "w") as resultat:
		resultat.write(str(A)+"\n")
		for (k, v) in intersection.items():
			l = list(v)
			resultat.write(str(k)+"\n")
			resultat.write(str(len(v))+"\n")
			for element in l:
				resultat.write(element[0]+" "+str(element[1])+"\n") 	

def main():
	mapGoogle, timeStreet, cars, D = parseur()
	#print("=====mapGoogle=====")
	#print(mapGoogle)
	#print("=====timeStreet=====")
	#print(timeStreet)
	#print("=====cars=====")
	#print(cars)
	temps = algo(mapGoogle, timeStreet, cars, D)
	A, intersection = analyse(temps, D)
	#print(A)
	#print(intersection)
	output(A, intersection)
	

main()