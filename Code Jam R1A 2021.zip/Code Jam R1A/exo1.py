def reverseSort(tab): 
    res = 0
    for i in range(1,len(tab)):
        if int(tab[i]) <= int(tab[i-1]) : 
            pre = [c for c in tab[i-1]]
            mtn = [c for c in tab[i]]

            quitter = False
            bis = False
            modi = False
            for j in range(len(mtn)):
                if mtn[j] != pre[j]: 
                    quitter = True
                    break
                if j == len(mtn)-1 and j == len(pre)-1: 
                    res += 1
                    tab[i] += "0"
                    break
                if j == len(mtn)-1:
                    for k in range(j+1,len(pre)) :
                        if k == len(pre) -1:
                            if modi : 
                                res += 1
                                tab[i] += pre[k]
                            else : 
                                for l in range(1,10): 
                                    if l > int(pre[k]): 
                                        res += 1
                                        tab[i] += str(l)
                                        bis = True
                                        break
                                if bis == False:
                                    res += 2
                                    tab[i] += "00"
                        else : 
                            if pre[k]=="9" or modi ==True:
                                res += 1
                                tab[i] += pre[k]
                            else : 
                                for l in range(1,10): 
                                    if l > int(pre[k]): 
                                        res += 1
                                        tab[i] += str(l)
                                        modi = True
                                        break
                                
            
            if quitter : 
                while(int(tab[i]) <= int(tab[i-1])): 
                    res += 1
                    tab[i] += "0"
    return res

def algo() : 

    output = []

    test = int(input())

    for i in range(1,test+1) : 
        L = int(input())
        ligne = input().split()
        tab = []
        for e in ligne: 
            tab.append(e)

        score = reverseSort(tab)
        s = "Case #"+str(i)+": "+str(score)
        output.append(s)
    
    for l in output : 
        print(l)

algo()


