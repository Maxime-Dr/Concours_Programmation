def reverseSort(tab): 
    if len(tab)==1:
        s = tab[0][1] +"/1"
        return (tab[0][0],s)
    else : 
        m = 0
        maRep = ""
        for e in tab:
            rep = e[0]
            point = int(e[1])
            if point > m :
                m =point
                maRep = rep
        s = str(m)+"/1"
        return (maRep,s)

def algo() : 

    output = []

    test = int(input())

    for i in range(1,test+1) : 
        ligne = input().split()
        N = int(ligne[0])
        S = int(ligne[1])
        tab = []
        for e in range(N): 
            tab.append(input().split())

        t = reverseSort(tab)
        s = "Case #"+str(i)+": "+t[0] + " " + t[1]
        output.append(s)
    
    for l in output : 
        print(l)

algo()


